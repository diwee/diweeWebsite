<?

$site[0] = "PHORTAIL"; // Titre du site
$site[1] = "PHORTAIL : site officiel !"; // Description du site
$site[2] = "PHORTAIL, PHP, GNU, GPL, script, scripting, HTML, web, internet"; // Mots-cl�s
$site[3] = "http://www.chez.com/nskate/"; // URL du site
$site[4] = "15"; // Nouvelles sur la page d'accueil
$site[5] = "0"; // Activation des newz ou pas

$user[0] = "Atchoum"; // Webmaster
$user[1] = "nskate@chez.com"; // Email du responsable du site
$user[2] = "104029240"; // # ICQ

$nom[0] = "Accueil"; // Nom de l'accueil
$nom[1] = "Downloads"; // Page des telechargements
$nom[2] = "Photos"; // Page des images
$nom[3] = "Liens"; // Page des liens
$nom[4] = ".: Articles :."; // Colonne des articles
$nom[5] = ".: Sp�cial ! :."; // Colonne speciale
$nom[6] = ".: Exprime-toi :."; // Sondage

$page[0] = "#FFCC00"; // Arriere-plan de la page
$page[1] = "Arial"; // Police du site
$page[2] = "12px"; // Taille des textes du site
$page[3] = ""; // Image de fond
$page[4] = "logo.gif"; // Logo

$titre[0] = "#000000"; // Couleur du titre
$titre[1] = "#DDDDDD"; // Arriere-plan du titre
$titre[2] = "Arial"; // Police des titres
$titre[3] = "18px"; // Taille des titres

$texte[0] = "#000000"; // Couleur des textes dans les cadres
$texte[1] = "#FFFFFF"; // Arriere-plan des textes dans les cadres OFF
$texte[2] = "#EEEEEE"; // Arriere-plan des textes dans les cadres ON

$bordure[0] = "#000000"; // Couleur des bordures

$lien[0] = "#0000FF"; // Lien OFF
$lien[1] = "#FF0000"; // Lien ON

?>