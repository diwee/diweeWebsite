<?

$mdp = "pass";

/* Si tu modifie le mot de passe, entoure bien son texte avec les guillemets */

?>